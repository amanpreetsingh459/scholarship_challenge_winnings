from setuptools import setup

setup(name = 'stat_dist',
      version = '0.1',
      description = 'Statistical distributions - Gaussian, Binomial etc..',
      packages = ['stat_dist'],
      author = 'Amanpreet Singh',
      author_email = 'amanpreetsingh459@gmail.com',
      zip_safe = False)
